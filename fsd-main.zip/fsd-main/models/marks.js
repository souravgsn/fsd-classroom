const { DataTypes } = require('sequelize')
const seq = require('../db/dbconfig')
const Marks = seq.define('Marks',{
    marks_id : {
        type : DataTypes.INTEGER,
        allowNull : false,
        primaryKey : true,
        autoIncrement : true,
    },

    sub1_mark : {
        type : DataTypes.INTEGER,
        allowNull : false,

    },

    student_id : {
        type: DataTypes.INTEGER,
        references : {
            model : 'students',
            key : 'student_id'
        }
    }


})

module.exports = Marks